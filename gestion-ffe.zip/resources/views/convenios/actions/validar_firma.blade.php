<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Validar firma de empresa') }}</h2>
    </x-slot>

    <!--
        TODO: Página para que el Tutor asignado valide la firma de la empresa.
        - Mostrar el PDF firmado y metadatos de la firma.
        - Botón para aceptar/rechazar la validación.
        - Si acepta: cambiar estado a `pendiente_firma_direccion`.
        - Si rechaza: indicar motivo y volver a `pendiente_firma_empresa` o `pendiente_secretaria` según el flujo.
    -->

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="text-sm text-gray-600">Aquí irá la UI para que el tutor valide la firma de la empresa.</p>
            </div>
        </div>
    </div>
</x-app-layout>
