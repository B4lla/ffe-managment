<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Descargar y firmar (Empresa)') }}</h2>
    </x-slot>

    <!--
        TODO: Página para que la Empresa descargue el PDF inicial y lo firme.
        - Mostrar enlace de descarga al PDF generado por Secretaría.
        - Instrucciones para firma (firma digital o subida de PDF firmado).
        - Tras la firma: subir fichero firmado y cambiar estado a `pendiente_validacion_tutor`.
        - Registrar trazabilidad (usuario, fecha, archivo).
    -->

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="text-sm text-gray-600">Aquí irá la interfaz para descargar y subir el PDF firmado por la empresa.</p>
            </div>
        </div>
    </div>
</x-app-layout>
