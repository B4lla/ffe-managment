<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Generar/Subir PDF inicial') }}</h2>
    </x-slot>

    <!--
        TODO: Interfaz para que Secretaría (o Administrador) genere o suba el PDF inicial.
        - Mostrar plantilla del convenio y datos rellenados.
        - Opción: generar PDF desde una vista Blade o subir un archivo PDF.
        - Al generar/subir: guardar referencia en el convenio y cambiar estado a `pendiente_firma_empresa`.
        - Registrar quién lo generó/subió y fecha.
    -->

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="text-sm text-gray-600">Aquí irá la UI para generar o subir el PDF inicial del convenio.</p>
            </div>
        </div>
    </div>
</x-app-layout>
