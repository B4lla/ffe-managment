<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Firmar por el centro') }}</h2>
    </x-slot>

    <!--
        TODO: Página para que Dirección firme el convenio.
        - Mostrar PDF validado por el tutor.
        - Proceso de firma por Dirección (digital o subir firmado).
        - Al firmar: cambiar estado a `en_vigor`.
        - Generar y almacenar versión final del convenio firmado por el centro.
    -->

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="text-sm text-gray-600">Aquí irá la UI para que Dirección firme el convenio y generar la versión final.</p>
            </div>
        </div>
    </div>
</x-app-layout>
