<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Insertar convenio') }}</h2>
    </x-slot>

    <!--
        TODO: Interfaz para crear un nuevo convenio.
        - Comprobar permisos (Administrador, Coordinador, Tutor, Secretaría).
        - Formulario para seleccionar/crear empresa, asignar tutor, fechas, horario, estado inicial.
        - Validación del lado servidor y mensajes de error.
        - Al enviar: crear el registro `Convenio` y redirigir al detalle.
    -->

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="text-sm text-gray-600">Aquí irá el formulario para insertar un convenio.</p>
            </div>
        </div>
    </div>
</x-app-layout>
