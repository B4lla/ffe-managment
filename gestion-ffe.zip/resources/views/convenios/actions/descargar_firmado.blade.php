<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Descargar convenio firmado') }}</h2>
    </x-slot>

    <!--
        TODO: Página para que la Empresa descargue la versión final firmada por el centro.
        - Mostrar enlace de descarga al PDF final (`en_vigor`).
        - Controlar accesos: solo Empresa propia o roles con permiso para ver.
        - Registrar descargas si es necesario.
    -->

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="text-sm text-gray-600">Aquí irá el enlace para descargar la versión final del convenio firmado.</p>
            </div>
        </div>
    </div>
</x-app-layout>
