<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ __('Meter datos iniciales') }}</h2>
    </x-slot>

    <!--
        TODO: Página para introducir los datos iniciales del convenio.
        - Debe permitir a la Empresa/Coordinador/Tutor completar campos necesarios.
        - Incluir campos obligatorios que hagan transitar el estado a `pendiente_secretaria`.
        - Mostrar validaciones y resumen antes de guardar.
        - Al guardar: actualizar el convenio y cambiar `estado`.
    -->

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="text-sm text-gray-600">Aquí irá el formulario para meter los datos iniciales del convenio.</p>
            </div>
        </div>
    </div>
</x-app-layout>
