<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Convenio')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <?php
                    $user = auth()->user();
                    $role = strtolower(trim((string) optional($user?->rol)->nombre ?? ''));
                    $isAssignedTutor = $user && isset($convenio->profesor_id) && $user->id === $convenio->profesor_id;
                ?>

                <div class="mb-4 flex gap-2 flex-wrap">
                    <?php if(in_array($role, ['administrador', 'coordinador', 'tutor', 'secretaria'], true)): ?>
                        <a href="<?php echo e(route('convenios.insertar')); ?>" class="inline-flex items-center px-3 py-1 bg-blue-600 text-black rounded-md">Insertar convenio</a>
                    <?php endif; ?>

                    <?php if(in_array($role, ['empresa', 'coordinador', 'tutor'], true) && ($convenio->estado === 'pendiente_datos')): ?>
                        <a href="<?php echo e(route('convenios.datos', $convenio->id)); ?>" class="inline-flex items-center px-3 py-1 bg-green-600 text-white rounded-md">Meter datos iniciales</a>
                    <?php endif; ?>

                    <?php if(in_array($role, ['secretaria', 'administrador'], true) && ($convenio->estado === 'pendiente_secretaria')): ?>
                        <a href="<?php echo e(route('convenios.generar_pdf', $convenio->id)); ?>" class="inline-flex items-center px-3 py-1 bg-yellow-600 text-white rounded-md">Generar/Subir PDF inicial</a>
                    <?php endif; ?>

                    <?php if($role === 'empresa' && ($convenio->estado === 'pendiente_firma_empresa')): ?>
                        <a href="<?php echo e(route('convenios.firmar_empresa', $convenio->id)); ?>" class="inline-flex items-center px-3 py-1 bg-indigo-600 text-white rounded-md">Descargar y firmar (Empresa)</a>
                    <?php endif; ?>

                    <?php if($isAssignedTutor && ($convenio->estado === 'pendiente_validacion_tutor')): ?>
                        <a href="<?php echo e(route('convenios.validar_firma', $convenio->id)); ?>" class="inline-flex items-center px-3 py-1 bg-purple-600 text-white rounded-md">Validar firma de empresa</a>
                    <?php endif; ?>

                    <?php if($role === 'direccion' && ($convenio->estado === 'pendiente_firma_direccion')): ?>
                        <a href="<?php echo e(route('convenios.firmar_centro', $convenio->id)); ?>" class="inline-flex items-center px-3 py-1 bg-red-600 text-white rounded-md">Firmar por el centro</a>
                    <?php endif; ?>

                    <?php if($role === 'empresa' && ($convenio->estado === 'en_vigor')): ?>
                        <a href="<?php echo e(route('convenios.descargar_firmado', $convenio->id)); ?>" class="inline-flex items-center px-3 py-1 bg-gray-600 text-white rounded-md">Descargar convenio firmado</a>
                    <?php endif; ?>
                </div>

                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-lg font-medium text-gray-900">Detalle del convenio</h3>
                    <a href="<?php echo e(route('convenios.index')); ?>" class="inline-flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">Volver</a>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h4 class="text-sm font-semibold text-gray-600">Empresa</h4>
                        <div class="mt-2 text-sm text-gray-800">
                            <div><strong>Nombre:</strong> <?php echo e($convenio->empresa->nombre_razon_social ?? '-'); ?></div>
                            <div><strong>DNI/CIF:</strong> <?php echo e($convenio->empresa->dni_cif ?? '-'); ?></div>
                            <div><strong>Categoria:</strong> <?php echo e($convenio->empresa->categoria ?? '-'); ?></div>
                            <div><strong>Tipo:</strong> <?php echo e($convenio->empresa->tipo ?? '-'); ?></div>
                            <div><strong>Email:</strong> <?php echo e($convenio->empresa->email ?? '-'); ?></div>
                            <div><strong>Telefono:</strong> <?php echo e($convenio->empresa->telefono1 ?? $convenio->empresa->telefono2 ?? '-'); ?></div>
                            <div><strong>Ubicacion:</strong> <?php echo e(trim(($convenio->empresa->municipio ?? '').' '.($convenio->empresa->provincia ?? '')) ?: '-'); ?></div>
                            <div><strong>Alta empresa:</strong> <?php echo e(optional($convenio->empresa->created_at)->format('d/m/Y') ?? '-'); ?></div>
                        </div>
                    </div>

                    <div>
                        <h4 class="text-sm font-semibold text-gray-600">Convenio</h4>
                        <div class="mt-2 text-sm text-gray-800">
                            <div><strong>ID:</strong> <?php echo e($convenio->id); ?></div>
                            <div><strong>Fecha inicio:</strong> <?php echo e(optional($convenio->fecha_inicio)->format('d/m/Y') ?? '-'); ?></div>
                            <div><strong>Fecha fin:</strong> <?php echo e(optional($convenio->fecha_fin)->format('d/m/Y') ?? '-'); ?></div>
                            <div><strong>Estado:</strong> <?php echo e($convenio->estado ?? '-'); ?></div>
                            <div class="mt-3"><strong>Observaciones:</strong>
                                <div class="mt-1 text-sm text-gray-700 whitespace-pre-wrap"><?php echo e($convenio->observaciones ?? '-'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Balla\Desktop\ffe\gestion-ffe\resources\views/convenios/show.blade.php ENDPATH**/ ?>