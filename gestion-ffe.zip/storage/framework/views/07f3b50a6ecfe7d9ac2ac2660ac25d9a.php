<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('header', null, []); ?> 
		<h2 class="font-semibold text-xl text-gray-800 leading-tight">
			<?php echo e(__('Crear Empresa')); ?>

		</h2>
	 <?php $__env->endSlot(); ?>

	<div class="py-12">
		<div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
			<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
				<?php if($errors->any()): ?>
					<div class="mb-4 rounded-md bg-red-50 p-3 text-sm text-red-700">
						<ul class="list-disc pl-5">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				<?php endif; ?>

				<form method="POST" action="<?php echo e(route('empresas.store')); ?>" class="space-y-5">
					<?php echo csrf_field(); ?>

					<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div>
							<label for="nombre_razon_social" class="block text-sm font-medium text-gray-700">Nombre / Razón Social</label>
							<input id="nombre_razon_social" name="nombre_razon_social" type="text" value="<?php echo e(old('nombre_razon_social')); ?>" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>

						<div>
							<label for="dni_cif" class="block text-sm font-medium text-gray-700">DNI / CIF</label>
							<input id="dni_cif" name="dni_cif" type="text" value="<?php echo e(old('dni_cif')); ?>" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>
					</div>

					<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div>
							<label for="categoria" class="block text-sm font-medium text-gray-700">Categoria</label>
							<input id="categoria" name="categoria" type="text" value="<?php echo e(old('categoria')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>

						<div>
							<label for="tipo" class="block text-sm font-medium text-gray-700">Tipo</label>
							<input id="tipo" name="tipo" type="text" value="<?php echo e(old('tipo')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>
					</div>

					<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div>
							<label for="email" class="block text-sm font-medium text-gray-700">Email</label>
							<input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>

						<div>
							<label for="telefono1" class="block text-sm font-medium text-gray-700">Teléfono 1</label>
							<input id="telefono1" name="telefono1" type="text" value="<?php echo e(old('telefono1')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>
					</div>

					<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div>
							<label for="telefono2" class="block text-sm font-medium text-gray-700">Teléfono 2</label>
							<input id="telefono2" name="telefono2" type="text" value="<?php echo e(old('telefono2')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>

						<div>
							<label for="provincia" class="block text-sm font-medium text-gray-700">Provincia</label>
							<input id="provincia" name="provincia" type="text" value="<?php echo e(old('provincia')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>
					</div>

					<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div>
							<label for="municipio" class="block text-sm font-medium text-gray-700">Municipio</label>
							<input id="municipio" name="municipio" type="text" value="<?php echo e(old('municipio')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>

						<div>
							<label for="codigo_postal" class="block text-sm font-medium text-gray-700">Código postal</label>
							<input id="codigo_postal" name="codigo_postal" type="text" value="<?php echo e(old('codigo_postal')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
						</div>
					</div>

					<div>
						<label for="direccion" class="block text-sm font-medium text-gray-700">Dirección</label>
						<textarea id="direccion" name="direccion" rows="3" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"><?php echo e(old('direccion')); ?></textarea>
					</div>

					<div class="flex items-center justify-end gap-3 pt-3">
						<a href="<?php echo e(route('empresas.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">
							Cancelar
						</a>
						<button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
							Guardar empresa
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Balla\Desktop\ffe\gestion-ffe\resources\views/empresas/create.blade.php ENDPATH**/ ?>