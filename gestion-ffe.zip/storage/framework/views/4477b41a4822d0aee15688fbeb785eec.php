<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Crear Convenio</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <?php if($errors->any()): ?>
                    <div class="mb-4 rounded-md bg-red-50 p-3 text-sm text-red-700">
                        <ul class="list-disc pl-5">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('convenios.store')); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>

                    <div>
                        <h3 class="text-lg font-medium">Responsable de la gestión</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Nombre</label>
                                <input name="responsable_nombre" type="text" value="<?php echo e(old('responsable_nombre')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Teléfono</label>
                                <input name="responsable_telefono" type="text" value="<?php echo e(old('responsable_telefono')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Email</label>
                                <input name="responsable_email" type="email" value="<?php echo e(old('responsable_email')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium">Responsable del IES LUIS BRAILLE</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Departamento</label>
                                <select id="departamento_select" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                                    <option value="">Selecciona departamento</option>
                                    <?php $__currentLoopData = $departamentos ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($departamento->id); ?>"><?php echo e($departamento->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700">Nombre Tutor</label>
                                <select id="tutor_select" name="tutor_id" disabled class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                                    <option value="">Selecciona tutor</option>
                                </select>
                            </div>

                            <div></div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Teléfono</label>
                                <input name="tutor_telefono" type="text" value="<?php echo e(old('tutor_telefono')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Email</label>
                                <input name="tutor_email" type="email" value="<?php echo e(old('tutor_email')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium">Datos de la empresa</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Nombre / Razón Social</label>
                                <input name="empresa_nombre" type="text" value="<?php echo e(old('empresa_nombre')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">DNI / CIF</label>
                                <input name="empresa_dni_cif" type="text" value="<?php echo e(old('empresa_dni_cif')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Actividad</label>
                                <input name="empresa_actividad" type="text" value="<?php echo e(old('empresa_actividad')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium">Domicilio Social</h3>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mt-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Provincia</label>
                                <input name="domicilio_provincia" type="text" value="<?php echo e(old('domicilio_provincia')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Municipio</label>
                                <input name="domicilio_municipio" type="text" value="<?php echo e(old('domicilio_municipio')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700">Dirección</label>
                                <input name="domicilio_direccion" type="text" value="<?php echo e(old('domicilio_direccion')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Código Postal</label>
                                <input name="domicilio_codigo_postal" type="text" value="<?php echo e(old('domicilio_codigo_postal')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium">Direcciones Centro de Trabajo</h3>
                        <div id="direcciones_container" class="space-y-4 mt-3">
                        </div>
                        <div class="mt-3">
                            <button type="button" id="add_direccion" class="inline-flex items-center px-3 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">Añadir dirección</button>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium">Contacto</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Teléfono 1</label>
                                <input name="contacto_telefono1" type="text" value="<?php echo e(old('contacto_telefono1')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Teléfono 2</label>
                                <input name="contacto_telefono2" type="text" value="<?php echo e(old('contacto_telefono2')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Email</label>
                                <input name="contacto_email" type="email" value="<?php echo e(old('contacto_email')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium">Representante</h3>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mt-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">NIF</label>
                                <input name="representante_nif" type="text" value="<?php echo e(old('representante_nif')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Nombre</label>
                                <input name="representante_nombre" type="text" value="<?php echo e(old('representante_nombre')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Apellido 1</label>
                                <input name="representante_apellido1" type="text" value="<?php echo e(old('representante_apellido1')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Apellido 2</label>
                                <input name="representante_apellido2" type="text" value="<?php echo e(old('representante_apellido2')); ?>" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 class="text-lg font-medium">Tutores (puede haber más de uno)</h3>
                        <div id="tutores_container" class="space-y-4 mt-3"></div>
                        <div class="mt-3">
                            <button type="button" id="add_tutor" class="inline-flex items-center px-3 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">Añadir tutor</button>
                        </div>
                        <p class="text-sm text-gray-500 mt-2">Horario: seleccione uno o varios horarios por defecto (16 opciones disponibles).</p>
                    </div>

                    <div class="flex items-center justify-end gap-3 pt-3">
                        <a href="<?php echo e(route('convenios.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">Cancelar</a>
                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-black rounded-md hover:bg-indigo-700">Crear convenio</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <template id="direccion_template">
        <div class="border rounded-md p-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Provincia</label>
                    <input name="direcciones[][provincia]" type="text" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Municipio</label>
                    <input name="direcciones[][municipio]" type="text" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700">Dirección</label>
                    <input name="direcciones[][direccion]" type="text" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Código Postal</label>
                    <input name="direcciones[][codigo_postal]" type="text" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
            </div>
            <div class="mt-3 text-right">
                <button type="button" class="remove_direccion inline-flex items-center px-3 py-2 bg-red-100 text-red-700 rounded-md">Eliminar</button>
            </div>
        </div>
    </template>

    <template id="tutor_template">
        <div class="border rounded-md p-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Nombre completo</label>
                    <input name="tutores[][nombre_completo]" type="text" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">DNI</label>
                    <input name="tutores[][dni]" type="text" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Horario (múltiple)</label>
                    <select name="tutores[][horarios][]" multiple class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                        <?php for($i = 1; $i <= 16; $i++): ?>
                            <option value="<?php echo e($i); ?>">Horario <?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="mt-3 text-right">
                <button type="button" class="remove_tutor inline-flex items-center px-3 py-2 bg-red-100 text-red-700 rounded-md">Eliminar</button>
            </div>
        </div>
    </template>

    <script>
        const tutoresByDept = <?php echo json_encode($tutoresByDept ?? [], 15, 512) ?>;

        document.addEventListener('DOMContentLoaded', function () {
            const depSelect = document.getElementById('departamento_select');
            const tutorSelect = document.getElementById('tutor_select');

            depSelect?.addEventListener('change', function () {
                const val = this.value;
                tutorSelect.innerHTML = '<option value="">Selecciona tutor</option>';
                if (val && tutoresByDept[val]) {
                    tutoresByDept[val].forEach(t => {
                        const opt = document.createElement('option');
                        opt.value = t.id;
                        opt.textContent = t.name;
                        tutorSelect.appendChild(opt);
                    });
                    tutorSelect.disabled = false;
                } else {
                    tutorSelect.disabled = true;
                }
            });

            const addDireccion = document.getElementById('add_direccion');
            const direccionesContainer = document.getElementById('direcciones_container');
            const direccionTpl = document.getElementById('direccion_template');

            addDireccion?.addEventListener('click', function () {
                const node = direccionTpl.content.cloneNode(true);
                direccionesContainer.appendChild(node);
            });

            direccionesContainer.addEventListener('click', function (e) {
                if (e.target.matches('.remove_direccion')) {
                    e.target.closest('div.border')?.remove();
                }
            });

            // Tutores repeater
            const addTutor = document.getElementById('add_tutor');
            const tutoresContainer = document.getElementById('tutores_container');
            const tutorTpl = document.getElementById('tutor_template');

            addTutor?.addEventListener('click', function () {
                const node = tutorTpl.content.cloneNode(true);
                tutoresContainer.appendChild(node);
            });

            tutoresContainer.addEventListener('click', function (e) {
                if (e.target.matches('.remove_tutor')) {
                    e.target.closest('div.border')?.remove();
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Balla\Desktop\ffe\gestion-ffe\resources\views/convenios/create.blade.php ENDPATH**/ ?>