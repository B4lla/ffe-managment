<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Usuarios')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <?php if(session('status')): ?>
                    <div class="mb-4 rounded-md bg-green-50 p-3 text-sm text-green-700">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <div class="flex justify-end mb-4">
                    <?php if($puede_gestionar): ?>
                        <a href="<?php echo e(route('usuarios.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-black border-2 border-black rounded-md hover:bg-indigo-700">
                            Crear usuario
                        </a>
                    <?php endif; ?>
                </div>

                <form method="GET" action="<?php echo e(route('usuarios.index')); ?>" class="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
                    <div>
                        <label for="rol_id" class="block text-sm font-medium text-gray-700">Rol</label>
                        <select id="rol_id" name="rol_id" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            <option value="">Todos</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rol->id); ?>" <?php if(($filtros['rol_id'] ?? '') == $rol->id): echo 'selected'; endif; ?>>
                                    <?php echo e($rol->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="departamento_id" class="block text-sm font-medium text-gray-700">Departamento</label>
                        <select id="departamento_id" name="departamento_id" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            <option value="">Todos</option>
                            <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($departamento->id); ?>" <?php if(($filtros['departamento_id'] ?? '') == $departamento->id): echo 'selected'; endif; ?>>
                                    <?php echo e($departamento->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="activo" class="block text-sm font-medium text-gray-700">Estado</label>
                        <select id="activo" name="activo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            <option value="">Todos</option>
                            <option value="1" <?php if(($filtros['activo'] ?? '') === '1'): echo 'selected'; endif; ?>>Activos</option>
                            <option value="0" <?php if(($filtros['activo'] ?? '') === '0'): echo 'selected'; endif; ?>>Inactivos</option>
                        </select>
                    </div>

                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">Email exacto</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="<?php echo e($filtros['email'] ?? ''); ?>"
                            placeholder="usuario@dominio.com"
                            class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                        >
                    </div>

                    <div class="flex items-end gap-2">
                        <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            Filtrar
                        </button>
                        <a href="<?php echo e(route('usuarios.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">
                            Limpiar
                        </a>
                    </div>
                </form>

                <div class="mb-4 text-sm text-gray-600">
                    Mostrando <?php echo e($usuarios->count()); ?> de <?php echo e($usuarios->total()); ?> usuarios
                </div>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Nombre</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Email</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">DNI/CIF</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Rol</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Departamento</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Estado</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Alta</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-4 py-3 text-sm text-gray-900"><?php echo e($usuario->nombre); ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-900"><?php echo e($usuario->email); ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e($usuario->dni_cif ?? '-'); ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e(optional($usuario->rol)->nombre ?? 'Sin rol'); ?></td>
                                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e(optional($usuario->departamento)->nombre ?? 'Sin departamento'); ?></td>
                                    <td class="px-4 py-3 text-sm">
                                        <?php if($usuario->activo): ?>
                                            <span class="px-2 py-1 rounded bg-green-100 text-green-700 text-xs font-medium">Activo</span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 rounded bg-red-100 text-red-700 text-xs font-medium">Inactivo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3 text-sm text-gray-700"><?php echo e(optional($usuario->created_at)->format('d/m/Y') ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="px-4 py-8 text-center text-sm text-gray-500">
                                        No hay usuarios para los filtros seleccionados.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-6">
                    <?php echo e($usuarios->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Balla\Desktop\ffe\gestion-ffe\resources\views/usuarios.blade.php ENDPATH**/ ?>