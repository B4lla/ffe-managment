<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('header', null, []); ?> 
		<h2 class="font-semibold text-xl text-gray-800 leading-tight">
			<?php echo e(__('Convenios')); ?>

		</h2>
	 <?php $__env->endSlot(); ?>

	<div class="py-12">
		<div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
			<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
				<form method="GET" action="<?php echo e(route('convenios.index')); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
					<div>
						<label for="q" class="block text-sm font-medium text-gray-700">Buscar</label>
						<input
							type="text"
							id="q"
							name="q"
							value="<?php echo e($filtros['q'] ?? ''); ?>"
							placeholder="Nombre, CIF, email, telefono..."
							class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
						>
					</div>

					<div>
						<label for="categoria" class="block text-sm font-medium text-gray-700">Categoria</label>
						<select id="categoria" name="categoria" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
							<option value="">Todas</option>
							<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($categoria); ?>" <?php if(($filtros['categoria'] ?? '') == $categoria): echo 'selected'; endif; ?>>
									<?php echo e($categoria); ?>

								</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

					<div>
						<label for="tipo" class="block text-sm font-medium text-gray-700">Tipo</label>
						<select id="tipo" name="tipo" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
							<option value="">Todos</option>
							<?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($tipo); ?>" <?php if(($filtros['tipo'] ?? '') == $tipo): echo 'selected'; endif; ?>>
									<?php echo e($tipo); ?>

								</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

					<div class="flex items-end gap-2">
						<button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
							Filtrar
						</button>
						<a href="<?php echo e(route('convenios.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">
							Limpiar
						</a>
					</div>
				</form>

				<?php if(session('status')): ?>
					<div class="mb-4 rounded-md bg-green-50 p-3 text-sm text-green-700">
						<?php echo e(session('status')); ?>

					</div>
				<?php endif; ?>

				<div class="flex justify-end mb-4">
					<?php if($puede_crear): ?>
						<a href="<?php echo e(route('convenios.create')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 text-black border-2 border-black rounded-md hover:bg-indigo-700">
							Crear convenio
						</a>
					<?php endif; ?>
				</div>

				<div class="mb-4 text-sm text-gray-600">
					Mostrando <?php echo e($convenios->count()); ?> de <?php echo e($convenios->total()); ?> convenios
				</div>

				<div class="overflow-x-auto">
					<table class="min-w-full divide-y divide-gray-200">
						<thead class="bg-gray-50">
							<tr>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Empresa</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">DNI/CIF</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Categoria</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Tipo</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Email</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Telefono</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Ubicacion</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Alta</th>
								<th class="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Ver</th>
							</tr>
						</thead>
						<tbody class="bg-white divide-y divide-gray-100">
							<?php $__empty_1 = true; $__currentLoopData = $convenios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $convenio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td class="px-4 py-3 text-sm text-gray-900"><?php echo e($convenio->empresa->nombre_razon_social); ?></td>
									<td class="px-4 py-3 text-sm text-gray-700"><?php echo e($convenio->empresa->dni_cif); ?></td>
									<td class="px-4 py-3 text-sm text-gray-700"><?php echo e($convenio->empresa->categoria ?? '-'); ?></td>
									<td class="px-4 py-3 text-sm text-gray-700"><?php echo e($convenio->empresa->tipo ?? '-'); ?></td>
									<td class="px-4 py-3 text-sm text-gray-700"><?php echo e($convenio->empresa->email ?? '-'); ?></td>
									<td class="px-4 py-3 text-sm text-gray-700"><?php echo e($convenio->empresa->telefono1 ?? $convenio->empresa->telefono2 ?? '-'); ?></td>
									<td class="px-4 py-3 text-sm text-gray-700"><?php echo e(trim(($convenio->empresa->municipio ?? '').' '.($convenio->empresa->provincia ?? '')) ?: '-'); ?></td>
									<td class="px-4 py-3 text-sm text-gray-700"><?php echo e(optional($convenio->empresa->created_at)->format('d/m/Y') ?? '-'); ?></td>
									<td class="px-4 py-3 text-sm text-indigo-600">
										<a href="<?php echo e(route('convenios.show', $convenio->id)); ?>" class="hover:underline">Ver</a>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td colspan="9" class="px-4 py-8 text-center text-sm text-gray-500">
										No hay convenios para los filtros seleccionados.
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>

				<div class="mt-6">
					<?php echo e($convenios->links()); ?>

				</div>
			</div>
		</div>
	</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Balla\Desktop\ffe\gestion-ffe\resources\views/convenios.blade.php ENDPATH**/ ?>